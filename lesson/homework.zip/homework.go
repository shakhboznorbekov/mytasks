package main

import (
	"fmt"
	"math/rand"
)

// 1-masala
// func main() {
// 	var musbat = []int{}
// 	var manfiy = []int{}
// 	i := 0
// 	for i < 500 {
// 		son := rand.Intn(2000) - 1000
// 		if son > 0 {
// 			musbat = append(musbat, son)
// 		} else {
// 			manfiy = append(manfiy, son)
// 		}
// 		i++
// 	}
// 	fmt.Println(musbat)
// 	fmt.Println(manfiy)
// }

//2-masala

// func main() {
// 	var text string = "Uyga vazifaRandom sonlar elon qiling. -1000 va 1000 gachahuni ichidagi minus sonlarni alohida slice ga joylashtiringva musbatlarni ham alohida slice ga joylashtiring.Va ekranga tartiblangan holatida chiqazingnums[500] = rand(-1000 dan 1000 gacha)2. Text qabul qiling va shuni teskari holatida qaytaruvchi function elong qilingva ekranga chiqazing3slice e'lon qiling va unga random sonlar 50 soling	Shu sonlar ichidan faqat tublarini chiqaruvchi funksiya tuzing.4. slice e'lon qiling va unga random sonlar soling.Shu sonlarng eng kattasini qaytaruvchi funksiya tuzing5. slice e'lon qiling va unga random sonlar soling.Shu sonlar ichidan 2-tub sonni qaytaruvchi funksiya tuzing."
// 	i := 500
// 	for i >= 0 {
// 		fmt.Printf("%s", string(text[i]))
// 		i--
// 	}
// }

//3-masala

func tub(a int) int {
	var tublar = []int{}
	i, result := 2, 0
	for i < a {
		if a%i == 0 {
			result++
		}
	}
	if result < 1 {
		tublar = append(tublar, result)
	}
	fmt.Println(tublar)
}

func main() {

	son := rand.Intn(50)
	i := 0
	for i < 50 {
		tub(son)
		i++
	}

}
